# UART Temperature Logger 🌡️

Simulated a DHT22 sensor-based temperature and humidity logger on **Wokwi**.  
Firmware in **Embedded C (Arduino)** reads sensor data every second, prints values via **UART**, and toggles an LED alert when temperature exceeds a threshold.

## 🧰 Tech Stack
- Embedded C / Arduino
- UART / GPIO
- DHT22 Sensor Simulation (Wokwi)
- LED control
- Serial communication

## ⚙️ Simulation
- Platform: [Wokwi Online Simulator](https://wokwi.com)
- Board: Arduino Uno
- Sensor: DHT22
- Baud Rate: 115200

## 📸 Output
![screenshot](screenshot.png)

## 🚀 Next Step
Porting the same firmware to **STM32 (FreeRTOS)** for multitasking and real-time data logging.

## 👨‍💻 Author
**Akash Adrashannavar**  
MS in IoT, Drexel University  
[LinkedIn Profile](https://www.linkedin.com/in/akash-adrashannavar-a4b8a4271/)
